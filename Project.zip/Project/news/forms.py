from .models import Articles
from django.forms import ModelForm, TextInput, DateTimeInput, Textarea


class ArticlesForm(ModelForm):
    class Meta:
        model = Articles
        fields = ['title', 'anons', "full_text", 'date']

        widgets = {
            'title': TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ім`я'
            }),
            'anons': TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Адреса для доставки'
            }),
            'full_text': Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Суть замовлення, побажання'
            }),
            'date': DateTimeInput(attrs={
                'class': 'form-control',
                'placeholder': 'Строк замовлення'
            })
        }
